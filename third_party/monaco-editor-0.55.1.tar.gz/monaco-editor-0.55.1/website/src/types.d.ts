/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

declare module "lzma/src/lzma_worker" {
	const x: any;
	export = x;
}
declare module "base64-js" {
	const x: any;
	export = x;
}
