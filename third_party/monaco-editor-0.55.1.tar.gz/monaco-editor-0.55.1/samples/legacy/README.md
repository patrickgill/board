These AMD samples are not supported anymore and will be removed in future releases.
Please use the ESM version of the editor!
