import * as monaco from 'monaco-editor/esm/vs/editor/editor.api';

// expose the monaco API as a global for tests
window.monacoAPI = monaco;
