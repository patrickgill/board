import './internal/initialize';
export * from 'monaco-editor-core';
