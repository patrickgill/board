import './internal/initialize';
/// @ts-ignore
export * from 'monaco-editor-core/esm/vs/editor/editor.api';
